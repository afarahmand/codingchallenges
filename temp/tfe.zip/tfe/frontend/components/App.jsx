import React from 'react';

// import GreetingContainer from './greeting/greeting_container';
import SessionFormContainer from './session_form_container';

const App = () => (
  <div>
    <SessionFormContainer/>
  </div>
);

export default App;
