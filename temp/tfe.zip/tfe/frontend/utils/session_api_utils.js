export const signin = user => (
  fetch('https://dev.trayt.io/v2/oauth2/token', {
    method: "POST",
    cache: "no-cache",
    credentials: "same-origin",
    headers: {
        "Content-Type": "application/json; charset=utf-8"
    },
    body: JSON.stringify({
      "username":user.email,
      "password":user.password,
      "client_id":"cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
      "grant_type":"password",
      "deviceId":"aaaaaaaaaa-BBbbb",
      "deviceName":"Computer"
    }),
  }).then(response => response.json())
);

// FROM https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
//
// function postData(url = ``, data = {}) {
//   // Default options are marked with *
//     return fetch(url, {
//         method: "POST", // *GET, POST, PUT, DELETE, etc.
//         mode: "cors", // no-cors, cors, *same-origin
//         cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
//         credentials: "same-origin", // include, same-origin, *omit
//         headers: {
//             "Content-Type": "application/json; charset=utf-8",
//             // "Content-Type": "application/x-www-form-urlencoded",
//         },
//         redirect: "follow", // manual, *follow, error
//         referrer: "no-referrer", // no-referrer, *client
//         body: JSON.stringify(data), // body data type must match "Content-Type" header
//     })
//     .then(response => response.json()); // parses response to JSON
// }
//
// var url = 'https://example.com/profile';
// var data = {username: 'example'};
//
// fetch(url, {
//   method: 'POST', // or 'PUT'
//   body: JSON.stringify(data), // data can be `string` or {object}!
//   headers:{
//     'Content-Type': 'application/json'
//   }
// }).then(res => res.json())
// .then(response => console.log('Success:', JSON.stringify(response)))
// .catch(error => console.error('Error:', error));





// const $ = require('jquery');
//
// export const signin = user => (
//   $.ajax({
//     url: 'https://dev.trayt.io/v2/oauth2/token',
//     method: 'POST',
//     // contentType: 'application/json; charset=UTF-8',
//     contentType: 'application/json',
//     dataType:'json',
//     // header: {
//     //   'Content-Type': 'application/json'
//     // },
//     body: {
//       "username":"trayt.testing+ashil@gmail.com",
//       "password":"135redwoodShor",
//       "client_id":"cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
//       "grant_type":"password",
//       "deviceId":"aaaaaaaaaa-BBbbb",
//       "deviceName":"Computer"
//       // username: "trayt.testing+ashil@gmail.com",
//       // password: "135redwoodShor",
//       // client_id: "cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
//       // grant_type: "password",
//       // deviceId: "aaaaaaaaaa-BBbbb",
//       // deviceName: "Computer"
//     },
//     data: {
//       "username":"trayt.testing+ashil@gmail.com",
//       "password":"135redwoodShor",
//       "client_id":"cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
//       "grant_type":"password",
//       "deviceId":"aaaaaaaaaa-BBbbb",
//       "deviceName":"Computer"
//       // username: "trayt.testing+ashil@gmail.com",
//       // password: "135redwoodShor",
//       // client_id: "cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
//       // grant_type: "password",
//       // deviceId: "aaaaaaaaaa-BBbbb",
//       // deviceName: "Computer"
//     }
//   })
// );

// username: "trayt.testing+ashil@gmail.com",
// password: "135redwoodShor",
// client_id: "cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
// grant_type: "password",
// deviceId: "aaaaaaaaaa-BBbbb",
// deviceName: "Computer"


// https://dev.trayt.io/v2/oauth2/token
// {
// "username":"trayt.testing+ashil@gmail.com",
// "password":"135redwoodShor",
// "client_id":"cM5iBlmyOvphECXy36QsgCxYOP9BJeCPQAOWhkhei8OdVX",
// "grant_type":"password",
// "deviceId":"aaaaaaaaaa-BBbbb",
// "deviceName":"Computer"
// }
